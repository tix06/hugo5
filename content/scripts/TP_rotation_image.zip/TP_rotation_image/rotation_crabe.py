from PIL import Image

# Défi n°1: copier l'image du crabe et explorer la structure de données

def copie_image(source):
    imageSource=Image.open(source)
    largeur,hauteur=imageSource.size
    planPixels=Image.new("RGB",(largeur,hauteur))

    for y in range(hauteur): # y varie de 0 à hauteur - 1
        for x in range(largeur): # x varie de 0 à largeur - 1
            p=imageSource.getpixel((x,y)) # p est la valeur RGB du pixel
            # la position d'un pixel sur l'image varie de (0,0) à (l-1,h-1)
            planPixels.putpixel((x,y),p) # nouvelle abscisse de 0 à h-1

    planPixels.save(source+"_copie.jpg")
    planPixels.show()



# Défi n°3: Utiliser ce script pour faire une rotation d'un quart de tour avec cette image du crabe

def rotation_image(source):
    imageSource=Image.open(source)
    largeur,hauteur=imageSource.size
    pass # à completer



