class Message:
    def __init__(self,clair,cle,chiffre):
        self.texte_clair = clair
        self.cle = cle
        self.texte_chiffre = chiffre

messages = [Message("le coq chantera trois fois",
                    "nouveautestament",
                    None),
            Message("je serai cette nuit une occasion de chute",
                    "enigma",
                    None),
            Message(None,
                    "alice",
                    "aaaaa l!ylat yhezsoar.mkplp "),
            Message("les sanglots longs des violons de l automne blessent mon coeur",
                    "verlaine",
                    None)]
