from messages import messages

# L'alphabet de 32 caractères utilisé pour le chiffrement
ALPHABET = 'abcdefghijklmnopqrstuvwxyz ?!/.,+'

def xor(n1,n2):
    """resultat de l'opération logique n1 XOR n2
    """
    b1 = '0'*(10-len(bin(n1)))+bin(n1)[2:]
    b2 = '0'*(10-len(bin(n2)))+bin(n2)[2:]
    b = ""
    for i in range(len(b1)):
        if b1[i] != b2[i]:
            b+='1' 
        else:
            b+='0'
    return int(b,2)

def generer_cle(mot,n):
    """renvoie la clé de longueur n à partir de la chaîne de caractères mot
    """
    pass

def test_generation_cle():
    assert generer_cle('cle',18) == 'clecleclecleclecle'
    assert generer_cle('ok',7)   == 'okokoko'

def rang_alphabet(c):
    """Renvoie le rang (entre 0 et 31) du caractère c dans ALPHABET.
    param: c str (un seul caractère appartenant à ALPHABET)
    """
    return ALPHABET.index(c)

def xor_crypt(message, cle):
    """Retourne le message chiffré à partir de la clé.
    Les rangs des caractères sont déterminés par rang_alphabet.
    Le résultat est composé uniquement de caractères de ALPHABET.
    param: message str (caractères de ALPHABET uniquement)
    param: cle str (caractères de ALPHABET uniquement)
    """
    pass

def test_xor_crypt():
    assert xor_crypt('bonjour monde', 'cle') == 'dfjlfqtrimghg'
    assert xor_crypt('dfjlfqtrimghg', 'cle') == 'bonjour monde'

def dechiffrer_tout(messages):
    """chiffre ou dechiffre les messages et place les resultats
    dans un dictionnaire
    """
    pass
