from math import sqrt
from donnees_habitats import zones_connues

nouveau = {'vegetation': 5, 'proximite_eau': 2,
           'densite_urbaine': 4, 'disponibilite_proies': 6}


zones = [
    {'vegetation': 9, 'proximite_eau': 6, 'densite_urbaine': 0,
        'disponibilite_proies': 4, 'presence_renard': True},
    {'vegetation': 10, 'proximite_eau': 5, 'densite_urbaine': 9,
        'disponibilite_proies': 10, 'presence_renard': False},
    {'vegetation': 8, 'proximite_eau': 5, 'densite_urbaine': 1,
        'disponibilite_proies': 6, 'presence_renard': False},
    {'vegetation': 8, 'proximite_eau': 5, 'densite_urbaine': 7,
        'disponibilite_proies': 6, 'presence_renard': True},
    {'vegetation': 6, 'proximite_eau': 9, 'densite_urbaine': 9,
        'disponibilite_proies': 6, 'presence_renard': True},
    {'vegetation': 5, 'proximite_eau': 3, 'densite_urbaine': 2,
        'disponibilite_proies': 9, 'presence_renard': False}
      ]

#######################################################################
# Question 1
#######################################################################

def distance(h1, h2):
    '''
    Calcule la distance euclidienne entre deux habitats.
    entrée : 
        - habitat_1 : dictionnaire représentant un habitat.
        - habitat_2 : dictionnaire représentant un autre habitat.
    sortie : 
        - float : distance euclidienne entre habitat_1 et habitat_2.
    '''
    v1 = h1['vegetation']
    v2 = h2['vegetation']
    p1 = h1['proximite_eau']
    p2 = h2['proximite_eau']
    d = ((v2-v1)**2+(p2-p1)**2)**0.5
    return d


#######################################################################
# Question 3
#######################################################################

def distance_d_un_habitat(habitat, habitats):
    '''
    Calcule la distance entre un habitat et chaque habitat de la liste.
    Et ajoute un couple 'distance':valeur 
    où valeur est la distance entre habitat et chaque habitat de la liste.
    entrée : 
        - habitat : dictionnaire représentant un habitat.
        - habitats : liste de dictionnaires représentant des habitats.
    sortie : 
        - None: la liste est modifiée en place
    '''
    pass
    


def trier(tableau, cle):
    '''
    trie le tableau selon l'une de ses clés
    entrée : 
        - tableau : liste de dictionnaires représentants les habitats.
        - cle : une des clés commune à chaque dictionnaire.
    sortie : 
        - None: la liste est triée en place
    '''
    tableau.sort(key=lambda x:x[cle])


#######################################################################
# Question 5
#######################################################################

def presence_renard(k, habitat, habitats):
    '''
    Vérifie si l'habitat donné a plus de k/2 voisins avec des renards.
    entrée : 
        - k : entier représentant le nombre d'habitats à considérer.
        - habitat : dictionnaire représentant un habitat.
        - habitats : liste de dictionnaires représentant des habitats.
    sortie : 
        - bool : True si l'habitat a plus de k/2 voisins avec des renards, False sinon.
    '''
    pass

#######################################################################
# partie réservée pour repondre aux questions 2, 4 et 6
#######################################################################