# Fichier de données – ne pas modifier

REQUETE_POST = "POST /login host=www.lycee-pasteur.fr payload=identifiant=alice&motdepasse=P@ssw0rd! version=1.0"
