from requete import REQUETE_POST


# -----------------------------------------------------------------------
# FONCTION FOURNIE – Partie 0
# Importe et retourne la requête depuis le fichier requete.py
# -----------------------------------------------------------------------

def charger_requete():
    """Retourne la chaîne REQUETE_POST importée depuis requete.py."""
    return REQUETE_POST


# -----------------------------------------------------------------------
# FONCTION FOURNIE – Partie 2
# Recherche dans une liste l'élément commençant par un préfixe donné
# -----------------------------------------------------------------------

def recherche_prefixe(liste, prefixe):
    """
    Retourne l'indice du premier élément de `liste`
    qui commence par la chaîne `prefixe`.
    Retourne -1 si aucun élément ne correspond.
    """
    for i in range(len(liste)):
        if liste[i].startswith(prefixe):
            return i
    return -1


# -----------------------------------------------------------------------
# PARTIE 1 – À compléter
# -----------------------------------------------------------------------

def decouper_requete(requete):
    """
    Prend en paramètre une chaîne de caractères représentant une requête
    HTTP et retourne la liste des éléments obtenus en découpant cette
    chaîne selon le caractère espace.

    Paramètre :
        requete (str) : la requête HTTP complète

    Retourne :
        list : liste des mots de la requête

    Exemple :
        decouper_requete("POST /login host=www.site.fr payload=id=bob")
        => ['POST', '/login', 'host=www.site.fr', 'payload=id=bob']
    """
    pass


# -----------------------------------------------------------------------
# PARTIE 3 – À compléter
# -----------------------------------------------------------------------

def extraire_credentials(requete_post):
    """
    Analyse une requête POST complète et retourne un dictionnaire
    contenant l'identifiant et le mot de passe extraits du payload.

    Cette fonction doit :
      1. Utiliser decouper_requete() pour obtenir la liste des éléments.
      2. Utiliser recherche_prefixe() pour localiser le payload.
      3. Extraire et découper le payload pour construire le dictionnaire.

    Paramètre :
        requete_post (str) : chaîne représentant une requête POST complète

    Retourne :
        dict : {'identifiant': ..., 'motdepasse': ...}

    Exemple :
        r = "POST /login host=www.site.fr payload=identifiant=alice&motdepasse=1234"
        extraire_credentials(r)
        => {'identifiant': 'alice', 'motdepasse': '1234'}
    """
    pass


# -----------------------------------------------------------------------
# PARTIE 4 – À compléter
# -----------------------------------------------------------------------

def score_mot_de_passe(mdp):
    """
    Calcule et retourne un score de force pour le mot de passe `mdp`.
    Le score est un entier compris entre 0 et 4, calculé ainsi :
      +1 si le mot de passe contient au moins 8 caractères
      +1 s'il contient au moins une lettre majuscule
      +1 s'il contient au moins une lettre minuscule
      +1 s'il contient au moins un caractère spécial parmi : @ & / ; . * $

    Paramètre :
        mdp (str) : le mot de passe à évaluer

    Retourne :
        int : score entre 0 et 4

    Exemples :
        score_mot_de_passe("abc")       => 1  (minuscule uniquement)
        score_mot_de_passe("P@ssw0rd!") => 4  (longueur + maj + min + spécial)
    """
    pass


# -----------------------------------------------------------------------
# Partie 5
# -----------------------------------------------------------------------
# FONCTION FOURNIE – Chargement du fichier de log
# -----------------------------------------------------------------------

def charger_logs(nom_fichier):
    """
    Ouvre le fichier `nom_fichier`, lit chaque ligne et retourne un tableau
    (liste) de chaînes de caractères, une par requête.
    Les lignes vides sont ignorées.

    Paramètre :
        nom_fichier (str) : chemin vers le fichier texte de logs

    Retourne :
        list : liste de chaînes, chaque chaîne étant une requête HTTP
    """
    logs = []
    with open(nom_fichier, 'r', encoding='utf-8') as fichier:
        for ligne in fichier:
            ligne = ligne.strip()       # supprime les espaces et sauts de ligne
            if ligne != '':            # ignore les lignes vides
                logs.append(ligne)
    return logs

# -----------------------------------------------------------------------
# PARTIE 5 – À compléter
# -----------------------------------------------------------------------

def extraire_tous_les_credentials(logs):
    """
    Prend en paramètre un tableau de chaînes `logs`, où chaque élément
    est une requête POST complète, et retourne un tableau de dictionnaires
    contenant les credentials extraits de chaque requête.

    Cette fonction doit utiliser extraire_credentials() pour traiter
    chaque requête une par une.

    Paramètre :
        logs (list) : liste de chaînes représentant des requêtes POST

    Retourne :
        list : liste de dictionnaires [{'identifiant': ..., 'motdepasse': ...}, ...]

    Exemple :
        logs = [
            "POST /login host=www.site.fr payload=identifiant=alice&motdepasse=1234",
            "POST /login host=www.site.fr payload=identifiant=bob&motdepasse=abcd",
        ]
        extraire_tous_les_credentials(logs)
        => [
            {'identifiant': 'alice', 'motdepasse': '1234'},
            {'identifiant': 'bob',   'motdepasse': 'abcd'},
        ]
    """
    pass


def analyser_mots_de_passe(liste_credentials):
    """
    Prend en paramètre le tableau de dictionnaires produit par
    extraire_credentials() et retourne un nouveau tableau de
    dictionnaires enrichi d'une clé 'score' pour chaque utilisateur.

    Cette fonction doit utiliser score_mot_de_passe() pour calculer
    le score de chaque mot de passe.

    Paramètre :
        liste_credentials (list) : liste de dicts {'identifiant': ..., 'motdepasse': ...}

    Retourne :
        list : liste de dicts {'identifiant': ..., 'motdepasse': ..., 'score': ...}

    Exemple :
        [{'identifiant': 'alice', 'motdepasse': '1234', 'score': 0}, ...]
    """
    pass

# -----------------------------------------------------------------------
# Programme principal – ne pas modifier
# -----------------------------------------------------------------------

if __name__ == "__main__":
    # Chargement de la requête
    requete = charger_requete()
    print("Requête chargée :", requete)
    print()

    # Partie 1
    elements = decouper_requete(requete)
    print("Partie 1 – Liste des éléments :", elements)
    print()

    # Partie 2
    i = recherche_prefixe(elements, "payload")
    print("Partie 2 – Indice du payload :", i)
    print("           Élément trouvé     :", elements[i] if i != -1 else "non trouvé")
    print()

    # Partie 3
    credentials = extraire_credentials(requete)
    print("Partie 3 – Credentials :", credentials)
    print()

    # Partie 4
    mdp = credentials["motdepasse"]
    score = score_mot_de_passe(mdp)
    print(f"Partie 4 – Mot de passe : {mdp!r}")
    print(f"           Score de force : {score}/4")

    # Partie 5
    """
    logs = charger_logs('logs.txt')
    print(f"Nombre de requêtes chargées : {len(logs)}")
    print()

    tous_credentials = extraire_tous_les_credentials(logs)
    print("Partie 1 – Tableau de credentials :")
    for c in tous_credentials:
        print(" ", c)
    print()

    resultats = analyser_mots_de_passe(tous_credentials)
    print("Partie 3 – Analyse des mots de passe :")
    for r in resultats:
        print(f"  {r['identifiant']:10s} | mdp: {r['motdepasse']:15s} | score: {r['score']}/4")
    """