# fonctions utiles pour le programme shifumi_main
def pierre(joueur,ordi):
    joueur,ordi = score(joueur,ordi,0)
    return joueur,ordi,"Joueur joue \n PIERRE"

def feuille():
    return "Joueur joue \n FEUILLE"

def ciseaux():
    return "Joueur joue \n CISEAUX"

def score(joueur,ordi,gagnant):
    """
    augmente le score du vainqueur de la manche
    :param joueur: score joueur
    :param ordi: score ordi
    :param gagnant: 0 pour joueur et 1 pour ordi
    :return: joueur, ordi
    """
    if gagnant:
        return joueur, ordi+1
    elif gagnant == 0:
        return joueur +1, ordi
    else:
        # cas match nul
        return joueur, ordi

