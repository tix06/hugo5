# Liens####
# http://www.xavierdupre.fr/app/teachpyx/helpsphinx/c_gui/tkinter.html
############

from tkinter import *
from PIL import Image, ImageTk
import shifumi_gameplay
from random import randint


def play_pierre(event):
    texte = "Joueur joue: \n PIERRE"
    txt1 = Label(fen1, text=texte, justify=LEFT, font='TkFixedFont')
    txt1.place(relx=1.0,
               rely=0.5,
               anchor='e')


def play_feuille(event):
    texte = "Joueur joue: \n FEUILLE"
    txt1 = Label(fen1, text=texte, justify=LEFT, font='TkFixedFont')
    txt1.place(relx=1.0,
               rely=0.5,
               anchor='e')


def play_ciseaux(event):
    texte = "Joueur joue: \n CISEAUX  "
    txt1 = Label(fen1, text=texte, justify=LEFT, font='TkFixedFont')
    txt1.place(relx=1.0,
               rely=0.5,
               anchor='e')


def replay():
    texte = "Cliquer \n pour jouer  "
    txt1 = Label(fen1, text=texte, justify=LEFT, font='TkFixedFont')
    txt1.place(relx=1.0,
               rely=0.5,
               anchor='e')


if __name__ == '__main__':
    fen1 = Tk()

    # création des widgets "esclaves" :
    can1 = Canvas(fen1, bg='dark grey', height=400, width=600)
    can1.pack(side=LEFT, padx=5, pady=5)
    bou1 = Button(fen1, text='Quitter', command=fen1.quit)
    bou1.pack(side=BOTTOM)
    bou2 = Button(fen1, text='(Re)Jouer', command=replay)
    bou2.pack()

    # Pierre
    image = Image.open("images/pierre.png")
    image = image.resize((image.size[0] // 2, image.size[1] // 2), Image.ANTIALIAS)
    photo_pierre = ImageTk.PhotoImage(image)

    pierre = can1.create_image(0, 0, anchor="nw", image=photo_pierre)
    can1.tag_bind(pierre, "<ButtonRelease>", play_pierre)


    # feuille
    image = Image.open("images/feuille.png")
    image = image.resize((image.size[0] // 2, image.size[1] // 2), Image.ANTIALIAS)
    photo_feuille = ImageTk.PhotoImage(image)

    feuille = can1.create_image(200, 0, anchor="nw", image=photo_feuille)
    can1.tag_bind(feuille, "<ButtonRelease>", play_feuille)
    # can1.pack()


    # ciseaux
    image = Image.open("images/ciseaux.png")
    image = image.resize((image.size[0] // 2, image.size[1] // 2), Image.ANTIALIAS)
    photo_ciseaux = ImageTk.PhotoImage(image)

    feuille = can1.create_image(400, 0, anchor="nw", image=photo_ciseaux)
    can1.tag_bind(feuille, "<ButtonRelease>", play_ciseaux)
    can1.pack()

    # Label
    replay()


    # mainloop
    fen1.mainloop()
