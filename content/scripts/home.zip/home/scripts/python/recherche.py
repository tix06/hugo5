## import
import os
from random import choice
import time
import numpy as np
os.chdir('U://Documents/scripts_python/dictionnaire_de_mots')




mots = []

# Lecture du fichier txt et remplissage de la liste
with open('liste_francais.txt', encoding='utf-8') as f:
    for mot in f.read().splitlines():
        mots.append(mot)

# Affichage des 13 derniers mots
print(len(mots))
mots[-13:]

##
from random import choice
choice(mots)
##
def recherche_mot(liste_mots):
    """
    recherche un mot dans une liste et renvoie l'indice si le mot est trouvée, -1 sinon
    Params :
    -------------------
    liste_mots : list, une liste de mots, dans un ordre quelconque.
    Variables :
    -----------
    X : str, mot défini aléatoirement dans la liste_mots

    Sortie :
    ------
    j : int, indice dans la liste
    Principe :
    --------
    X est un mot tiré aleatoirememt avec choice(liste_mots)
    on parcourt la liste avec une boucle non bornée, tant que X n'est pas trouvé dans la liste
    on augmente la valeur de j à chaque nouvelle itération
    """
    j = 0
    n = len(liste_mots)
    X = choice(mots)  # a completer
    while j<n and X!=liste_mots[j]:
        j += 1 # à completer
    if j==n : return -1
    return j

recherche_mot(mots)

##
import time
t0 = time.time()
recherche_mot(mots)
t1 = time.time()
t1-t0 # affichage en s
## fichier liste_francais.txt
import numpy as np
mots = []
with open('liste_francais.txt', encoding='utf-8') as f:
    for mot in f.read().splitlines():
        mots.append(mot)

T = []
L = []
# a completer
# appel de la fonction recherche_mot et ajouter le temps
# a la liste T
for i in range(1000):
    t0 = time.time()
    recherche_mot(mots)
    t1 = time.time()
    T.append(t1-t0)
r = np.mean(T)
L.append((len(mots),r))

## fichier ods4.txt
with open('ods4.txt', encoding='utf-8') as f:
    for mot in f.read().splitlines():
        mots.append(mot)
T = []

for i in range(1000):
    t0 = time.time()
    recherche_mot(mots)
    t1 = time.time()
    T.append(t1-t0)
r = np.mean(T)
L.append((len(mots),r))

## fichier pli07.txt
with open('pli07.txt', encoding='utf-8') as f:
    for mot in f.read().splitlines():
        mots.append(mot)
T = []

for i in range(1000):
    t0 = time.time()
    recherche_mot(mots)
    t1 = time.time()
    T.append(t1-t0)
r = np.mean(T)
L.append((len(mots),r))
## fichier gutenberg.txt
with open('gutenberg.txt', encoding='utf-8') as f:
    for mot in f.read().splitlines():
        mots.append(mot)
T = []

for i in range(1000):
    t0 = time.time()
    recherche_mot(mots)
    t1 = time.time()
    T.append(t1-t0)
r = np.mean(T)
L.append((len(mots),r))
##
L.append((0,0))

## graphique
import matplotlib.pyplot as plt
# creation de listes x,y a l'aide de la librairie np
L = np.array(L)
x = L[:,0]
y = L[:,1]
plt.scatter(x,y)
plt.xlabel('N mots')
plt.ylabel('temps moyen de recherche')
plt.show()
