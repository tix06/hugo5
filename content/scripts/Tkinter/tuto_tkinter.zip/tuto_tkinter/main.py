from tkinter import *
from PIL import Image, ImageTk



def replay():
    """(re)demarrage du jeu et de la calibration"""
    global echelle
    can1.delete('all')
    # dessiner quelque chose dans le canvas
    text_affichage.set("Commencer la partie")



if __name__ == '__main__':
    fen1 = Tk()
    # variable texte pour label
    text_affichage = StringVar()
    # création des widgets "esclaves" :
    # le canvas
    can1 = Canvas(fen1, bg='dark grey', height=400, width=600)
    can1.pack(side=LEFT, padx=5, pady=5)
    # un bouton
    bou1 = Button(fen1, text='Quitter', command=fen1.quit)
    bou1.pack(side=BOTTOM)
    # un autre bouton
    bou2 = Button(fen1, text='(Re)Jouer', command=replay)
    bou2.pack()
    # Label: texte que l'on peut modifier avec
    # text_affichage.set("le texte affiché")
    txt1 = Label(fen1, textvariable=text_affichage, justify=LEFT, font='TkFixedFont')
    txt1.pack()

    # initialiser la canvas
    replay()
    # mainloop
    fen1.mainloop()
