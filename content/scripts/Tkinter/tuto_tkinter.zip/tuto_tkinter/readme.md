# fichiers de demarrage pour le tp decouvrir Tkinter
## Contenu
* fichier main.py: c'est le fichier qu'il faudra executer à l'aide d'un IDE python
* dossier images: images diverses à utiliser selon le jeu choisi

## Principe
Suivre le tutoriel sur allophysique.com/docs/NSI_1/IHM/tkinter1/

Modifier le fichier main.py au fur et à mesure de la lecture du TP. Executer le fichier main.py pour lancer le programme.


