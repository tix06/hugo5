from random import randint


def position_bombes(L,h):
    """
    grille vide
    :param L: nombre de cases horizontales
    :param h: nombre de cases verticales
    :return Bombes: matrice de dimension L*h
    retourne une liste de binaires avec la position des bombes

    exemple:
    --------
    >>> position_bombes(2,2)
    [[0, 0], [0, 0]]
    """
    Bombes = [] # Liste de bombes à 2 dimensions
    for i in range(h):
        ligne = []
        for j in range(L):
            ligne.append(0)
        Bombes.append(ligne)
    return Bombes


