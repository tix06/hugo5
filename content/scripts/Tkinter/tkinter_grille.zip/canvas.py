from tkinter import *
from PIL import Image, ImageTk
from utils import *

def carre(r,X,Y,couleur):
    """
    dessine le contour d'une case
    """
    global can1
    can1.create_rectangle(X, Y, X+r, Y+r, outline = 'black',fill = couleur)

def dessine(echelle,Bombes):
    """
    dessine le canvas avec quadrillage et mini bombes
    """
    global can1
    # les arguments du nombre de cases horizontales et verticales
    # ne dependent que de la variable echelle
    # La largeur et la hauteur du canvas can1
    for j in range(int(can1['height'])//echelle):
        for i in range(int(can1['width'])//echelle):
            carre(echelle,i*echelle,j*echelle,'grey')
            if Bombes[j][i] == 1:
                bomb = can1.create_image(i*echelle, j*echelle, anchor="nw", image=image_bomb)

if __name__ == '__main__':
    fen1 = Tk()
    # cote carres 100px
    echelle = 100

    # variable texte pour label
    text_affichage = StringVar()
    # création des widgets "esclaves" :
    can1 = Canvas(fen1, bg='dark grey', height=600, width=600)
    can1.pack(side=LEFT, padx=5, pady=5)

    bou1 = Button(fen1, text='Quitter', command=fen1.quit)
    bou1.pack(side=BOTTOM)

    # Label
    txt1 = Label(fen1, textvariable=text_affichage, justify=LEFT, font='TkFixedFont')
    txt1.pack()
    text_affichage.set("Dessiner avec Tkinter")

    # bombe coin superieur
    image = Image.open("images/bomb.png")
    image = image.resize((echelle, echelle), Image.ANTIALIAS)
    image_bomb = ImageTk.PhotoImage(image)
    miniature = image.resize((echelle//4, echelle//4), Image.ANTIALIAS)
    image_miniature = ImageTk.PhotoImage(miniature)

    # calcul positions bombes
    # les arguments du nombre de cases horizontales et verticales
    # ne dependent que de la variable echelle
    # La largeur et la heuteur du canvas can1
    Bombes = position_bombes(int(can1['width'])//echelle,int(can1['height'])//echelle)

    dessine(echelle,Bombes)
    # mainloop
    fen1.mainloop()
