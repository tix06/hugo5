def filtre1(r,v,b):
    r = r
    v = 0
    b = 0
    return r,v,b

def filtre2(r,v,b):
    r = 0
    v = v
    b = b
    return r,v,b