from tkinter import *
from PIL import Image, ImageTk
#import tkinter as Tk
#from tkinter import ttk
from tkinter import filedialog as fd
import filtres
#from tkinter.messagebox import showinfo

"""
# create the root window
fen0 = tk.Tk()
fen0.title('Tkinter Open File Dialog')
fen0.resizable(False, False)
fen0.geometry('300x150')


def select_file():
    filetypes = (
        #('text files', '*.txt'),
        ('img files', '*.png'),
        ('All files', '*.*')
    )

    filename = fd.askopenfilename(
        title='Open a file',
        initialdir='/',
        filetypes=filetypes)
    
    showinfo(
        title='Selected File',
        message=filename
    )
    
    print(filename)


# open button
open_button = ttk.Button(
    fen0,
    text='Open a File',
    command=select_file
)

open_button.pack(expand=True)
"""
class fenetre(Tk):
    def __init__(self):
        Tk.__init__(self)
        # création des widgets "esclaves" :
        self.height = 400
        self.width = 600
        self.can1 = Canvas(self, bg='dark grey', height=self.height, width=self.width)
        self.can1.pack(side=LEFT, padx=5, pady=5)
        self.image = "avatar.png"
        # nom des images traitees
        self.im = None
        self.im_rouge = None
        self.im_cyan = None
        # dimansion des images traitees
        self.im_X = 0
        self.im_Y = 0 
        self.coef_X = 4
        self.coef_Y = 4
        self.create()
        self.replay()


    def replay(self):
        self.txt1.destroy()
        self.txt1 = Label(self, text='vous avez deja \n une image')


    def select_file(self,event=None):
        filetypes = (
            # ('text files', '*.txt'),
            ('img files', '*.png'),
            ('All files', '*.*')
        )

        filename = fd.askopenfilename(
            title='Open a file',
            initialdir='/',
            filetypes=filetypes)

        self.image = filename
        self.txt1.destroy()
        self.txt1 = Label(self, text=self.image)
        print(self.image)

        self.can1.delete("all")
        # image d'origine
        self.im = Image.open(self.image)
        self.im_X = self.im.size[0]
        self.im_Y = self.im.size[1]
        self.redimensionne()
        self.im = self.im.resize((int(self.im_X / self.coef_X), int(self.im_Y / self.coef_Y)), Image.ANTIALIAS)
        self.photo_origin = ImageTk.PhotoImage(self.im)

        self.im_origin = self.can1.create_image(0, 0, anchor="nw", image=self.photo_origin)
        self.can1.tag_bind(self.im_origin, "<ButtonRelease>", self.select_file)


        """
        showinfo(
            title='Selected File',
            message=filename
        )
        """

    def redimensionne(self):
        self.coef_X =   round((2*self.im_X) / (self.width-50),1)
        self.coef_Y =  round((2*self.im_Y) / (self.height-50),1)
        self.coef_X, self.coef_Y = max(self.coef_X, self.coef_Y), max(self.coef_X, self.coef_Y)
        print(self.coef_X, self.coef_Y)

    def rouge(self):
        image = Image.open(self.image)
        (c, l) = image.size
        imagearrivee = Image.new(image.mode, image.size)
        for x in range(c):
            for y in range(l):
                pixel = image.getpixel((x, y))
                # p=(pixel[0],0,0)
                p = filtres.filtre1(int(pixel[0]), int(pixel[1]), int(pixel[2]))
                imagearrivee.putpixel((x, y), p)
        imagearrivee.save("photo_rouge.png")
        print('creation de la photo avec filtre 1')
        self.im_rouge = Image.open("photo_rouge.png")
        self.im_rouge = self.im_rouge.resize((int(self.im_X / self.coef_X), int(self.im_Y / self.coef_Y)), Image.ANTIALIAS)
        self.photo_rouge = ImageTk.PhotoImage(self.im_rouge)
        self.im_rouge = self.can1.create_image(self.im.size[0] +20, 0, anchor="nw", image=self.photo_rouge)

    def cyan(self):
        image = Image.open(self.image)
        (c, l) = image.size
        imagearrivee = Image.new(image.mode, image.size)
        for x in range(c):
            for y in range(l):
                pixel = image.getpixel((x, y))
                # p=(pixel[0],0,0)
                p = filtres.filtre2(int(pixel[0]), int(pixel[1]), int(pixel[2]))
                imagearrivee.putpixel((x, y), p)
        imagearrivee.save("photo_cyan.png")
        print('creation de la photo avec filtre 2')
        self.im_cyan = Image.open("photo_cyan.png")
        self.im_cyan = self.im_cyan.resize((int(self.im_X / self.coef_X), int(self.im_Y / self.coef_Y)), Image.ANTIALIAS)
        self.photo_cyan = ImageTk.PhotoImage(self.im_cyan)
        self.im_cyan = self.can1.create_image(0, self.im_cyan.size[1] + 20, anchor="nw", image=self.photo_cyan)

    def ajoutborddroit(self,imR):
        if self.im_rouge != None:
            imagedepart = Image.open(imR)
            (c, l) = imagedepart.size
            imagearrivee = Image.new(imagedepart.mode, (c + 20, l))
            for x in range(c):
                for y in range(l):
                    pixel = imagedepart.getpixel((x, y))
                    imagearrivee.putpixel((x, y), pixel)
            for x in range(c, c + 20):
                for y in range(l):
                    imagearrivee.putpixel((x, y), (255, 255, 255))
            imagearrivee.save("photo_augmentee_droit.png")
            print('ajout du bord droit')

    def ajoutbordgauche(self,imC):
        if self.im_cyan != None:
            imagedepart = Image.open(imC)
            (c, l) = imagedepart.size
            imagearrivee = Image.new(imagedepart.mode, (c + 20, l))
            for x in range(20):
                for y in range(l):
                    imagearrivee.putpixel((x, y), (255, 255, 255))
            for x in range(20, c + 20):
                for y in range(l):
                    pixel = imagedepart.getpixel((x - 20, y))
                    imagearrivee.putpixel((x, y), pixel)
            imagearrivee.save("photo_augmentee_gauche.png")
            print('ajout du bord gauche')

    def superpose(self):
        if self.im_rouge != None and self.im_cyan != None:
            imR = 'photo_rouge.png'
            imC = 'photo_cyan.png'
            self.ajoutborddroit(imR)
            self.ajoutbordgauche(imC)
            image1 = Image.open('photo_augmentee_droit.png')
            image2 = Image.open('photo_augmentee_gauche.png')
            (c, l) = image1.size
            imagearrivee = Image.new(image1.mode, (c, l))
            for x in range(c):
                for y in range(l):
                    pixel1 = image1.getpixel((x, y))
                    pixel2 = image2.getpixel((x, y))
                    r = max(pixel1[0], pixel2[0])
                    g = max(pixel1[1], pixel2[1])
                    b = max(pixel1[2], pixel2[2])
                    imagearrivee.putpixel((x, y), (r, g, b))
            imagearrivee.save("photo_resultat.png")
            print('creation d\'une image par superposition')
            self.im_resul = Image.open("photo_resultat.png")
            self.im_resul = self.im_resul.resize((int(self.im_X / self.coef_X), int(self.im_Y / self.coef_Y)), Image.ANTIALIAS)
            self.photo_resul = ImageTk.PhotoImage(self.im_resul)
            self.im_resul = self.can1.create_image(self.im_resul.size[0] + 20, self.im_resul.size[1] + 20, anchor="nw", image=self.photo_resul)

    def create(self):
            self.bou1 = Button(self, text='Quitter', command=self.quit)
            self.bou1.pack(side=BOTTOM)
            self.txt1 = Label(self, text='Choisir une image')
            self.bou2 = Button(self, text='select image', command=self.select_file)
            self.bou2.pack()
            self.bou3 = Button(self, text='filtre 1', command=self.rouge)
            self.bou3.pack()
            self.bou4 = Button(self, text='filtre 2', command=self.cyan)
            self.bou4.pack()
            self.bou5 = Button(self, text='entrelacer', command=self.superpose)
            self.bou5.pack()

            # image d'origine
            self.im = Image.open(self.image)
            self.im_X = self.im.size[0]
            self.im_Y = self.im.size[1]
            self.redimensionne()
            self.im = self.im.resize((int(self.im_X / self.coef_X), int(self.im_Y / self.coef_Y)), Image.ANTIALIAS)
            #print('image redimensionné self.coef_X vaut {}, self.coef_Y vaut {}'.format(self.coef_X, self.coef_Y))
            
            self.photo_origin = ImageTk.PhotoImage(self.im)

            self.im_origin = self.can1.create_image(0, 0, anchor="nw", image=self.photo_origin)
            self.can1.tag_bind(self.im_origin, "<ButtonRelease>", self.select_file)


            #self.affichage = Label(self, text='')





# run the application
if __name__ == '__main__':
    fen0 = fenetre()
    fen0.mainloop()
